# Exlantic Growth Partners website

Static site (HTML/CSS/JS, no build step, no dependencies) plus one Cloudflare Pages Function for the contact form.

## Structure
- `index.html`, `css/styles.css`, `js/main.js`, `assets/`
- `functions/api/contact.js` — sends the form to exlanticgrowth@gmail.com
- `_headers`, `robots.txt`

## Deploy on Cloudflare Pages (free)
1. Create a free Resend account (resend.com) **using exlanticgrowth@gmail.com** and create an API key.
   (With the default test sender, Resend only delivers to the account owner's address. To send from your own domain, verify it in Resend and set `CONTACT_FROM`.)
2. Put this folder in a GitHub repo, or use Cloudflare Pages "Direct Upload" and upload the folder.
3. Cloudflare dashboard > Workers & Pages > Create > Pages. Framework preset: None. Build command: empty. Output directory: `/`.
4. Pages project > Settings > Variables and Secrets: add secret `RESEND_API_KEY`. Redeploy.
5. Submit the form once to confirm the email arrives.

## Things to complete
- Replace the Instagram link in `index.html` (footer) with the real profile URL.
- Add the founder photo: replace the `.photo` block with `<img src="assets/hussain-khan.jpg" alt="Hussain Khan">`.
- Add a sitemap.xml and canonical URL once the domain is known.
- Future business areas: add a new `<section>` and a nav link; styles are reusable (`.sec`, `.cards`, `.card`). Nothing is listed publicly yet.
