// Cloudflare Pages Function: POST /api/contact
// Sends form submissions to exlanticgrowth@gmail.com through Resend (https://resend.com).
// Required environment variable: RESEND_API_KEY (Cloudflare Pages > Settings > Variables and Secrets).
// Optional: CONTACT_TO (defaults to exlanticgrowth@gmail.com), CONTACT_FROM (defaults to Resend's test sender).
const json = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export async function onRequestPost({ request, env }) {
  let d;
  try { d = await request.json(); } catch { return json({ error: 'Invalid request.' }, 400); }
  if (d.website) return json({ ok: true }); // honeypot: silently drop bots

  const name = String(d.name || '').trim(), email = String(d.email || '').trim(),
        company = String(d.company || '').trim(), subject = String(d.subject || '').trim(),
        message = String(d.message || '').trim();
  if (!name || !subject || !message || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return json({ error: 'Missing or invalid fields.' }, 400);
  if (!env.RESEND_API_KEY) return json({ error: 'Email service is not configured.' }, 500);

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: env.CONTACT_FROM || 'Exlantic Website <onboarding@resend.dev>',
      to: [env.CONTACT_TO || 'exlanticgrowth@gmail.com'],
      reply_to: email,
      subject: `[Exlantic website] ${subject.slice(0, 150)}`,
      html: `<p><b>Name:</b> ${esc(name)}</p><p><b>Email:</b> ${esc(email)}</p><p><b>Company:</b> ${esc(company || '-')}</p><p><b>Message:</b></p><p>${esc(message).replace(/\n/g, '<br>')}</p>`,
    }),
  });
  return res.ok ? json({ ok: true }) : json({ error: 'Email provider rejected the request.' }, 502);
}
