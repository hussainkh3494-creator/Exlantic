(function () {
  var btn = document.querySelector('.menu-btn'), menu = document.getElementById('menu');
  btn.addEventListener('click', function () {
    var open = menu.classList.toggle('open');
    btn.setAttribute('aria-expanded', open);
  });
  menu.addEventListener('click', function (e) {
    if (e.target.tagName === 'A') { menu.classList.remove('open'); btn.setAttribute('aria-expanded', false); }
  });

  var form = document.getElementById('form'), status = document.getElementById('status');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    status.className = '';
    if (!form.checkValidity()) { status.className = 'err'; status.textContent = 'Please complete the required fields with a valid email address.'; return; }
    var submit = form.querySelector('button'); submit.disabled = true; status.textContent = 'Sending…';
    fetch(form.action, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(form))) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error(res.j.error || 'failed');
        form.reset(); status.className = 'ok'; status.textContent = 'Message sent. We will get back to you soon.';
      })
      .catch(function () {
        status.className = 'err'; status.textContent = 'Your message was not sent. Please email exlanticgrowth@gmail.com directly.';
      })
      .finally(function () { submit.disabled = false; });
  });
})();
